// My Code***********

// API routes for Controller callback functions
//a Separate responsibility  for navigation
var orderdetailsController=require("./controllers/orderdetailsController");
var ordersController=require("./controllers/ordersController");
var customersController=require("./controllers/customersController");
var flowerController=require("./controllers/flowerscontroller");

//get the app object of express from server.js

module.exports=function(app){

    //Orderdeatils HTTP request Mapping
   
    app.route("/api/orderdetails")              
    .get(orderdetailsController.getAll)          //http://localhost:9898/api/orders/       GET  
    .post(orderdetailsController.insert);         //http://localhost:9898/api/orders/       POST

    app.route('/api/orderdetails/:id')
    .get(orderdetailsController.getBy)           //http://localhost:9898/api/orders/:orderid    GET
    .put(orderdetailsController.update)          //http://localhost:9898/api/orders/:orderid    PUT
    .delete(orderdetailsController.remove);      //http://localhost:9898/api/orders/:orderid    DELETE 

    //Orders HTTP request Mapping
   
    app.route("/api/orders")              
    .get(ordersController.getAll)          //http://localhost:9898/api/orders/       GET  
    .post(ordersController.insert);         //http://localhost:9898/api/orders/       POST

    app.route('/api/orders/:id')
    .get(ordersController.getBy)           //http://localhost:9898/api/orders/:orderid    GET
    .put(ordersController.update)          //http://localhost:9898/api/orders/:orderid    PUT
    .delete(ordersController.remove);      //http://localhost:9898/api/orders/:orderid    DELETE 
    
    //Customers  HTTP request Mapping******************
         
    app.route("/api/customers")              
    .get(customersController.getAll)           //http://localhost:9898/api/customers/       GET  
    .post(customersController.insert);         //http://localhost:9898/api/customers/       POST

    app.route('/api/customers/:id')
    .get(customersController.getBy)           //http://localhost:9898/api/customers/:custid    GET
    .put(customersController.update)          //http://localhost:9898/api/customers/:custid    PUT
    .delete(customersController.remove);      //http://localhost:9898/api/customers/:custid    DELETE 
    
     //Flowers HTTP request Mapping**********************  
     app.route("/api/flowers")              
     .get(flowerController.getAll)           //http://localhost:9898/api/flowers/       GET  
     .post(flowerController.insert);         //http://localhost:9898/api/flowers/       POST
 
     app.route('/api/flowers/:id')
     .get(flowerController.getBy)           //http://localhost:9898/api/flowers/:id    GET
     .put(flowerController.update)          //http://localhost:9898/api/flowers/:id    PUT
     .delete(flowerController.remove);      //http://localhost:9898/api/flowers/:id    DELETE    

    //Orders HTTP request Mapping 
    //OrderItems HTTP request Mapping 
    //ShopingCart HTTP request Mapping 
    //Payments HTTP request Mapping 
};
//Express Routing is a mechanism to mapping incomming HTTP requests with appropriate controller functions
