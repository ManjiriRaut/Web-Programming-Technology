//**************************** */
//a Separate responsibility  for  Flowers  HTTP request handling

var Order = require('../dal/ordersDal');

exports.getAll = function(req, res) {
  console.log("calling controller function");
  Order.getAllOrder(function(err, order) {  //invoking this fun from flowersDal file
    if (err)
      res.send(err);
    res.send(order);
  });
};

exports.insert = function(req, res) {
  var new_Order = new Order(req.body);
  console.log(new_Order.body); //print at console

  //handles null error 
   if(!new_Order.orderid || !new_Order.orderdate){
      res.status(400).send({ error:true, message: 'Please provide Order/status' });
    }
   else{
    Order.createOrder(new_Order, function(err, Order) {
      if (err)
      res.send(err);
      res.json(Order);
    });
  }
};

exports.getBy = function(req, res) {
  Order.getOrderById(req.params.id, function(err, order) {
    if (err)
      res.send(err);
    res.json(order);
  });
};

exports.update = function(req, res) {
  Order.updateById(req.params.id, new Order(req.body), function(err, order) {
    if (err)
      res.send(err);
    res.json(order);
    console.log("Order Table is updated...!!!");
  });
};

exports.remove = function(req, res) {
  Order.remove( req.params.id, function(err, order) {
    if (err)
      res.send(err);
    res.json({ message: 'Order successfully deleted' });
    console.log("Order is deleted...!!");
  });
};