//************************************ */
//a Separate responsibility  for  Flowers database crud operation
//DAL : Data Access Logic in this dal file
var sql = require('./mysqlconnect');

//model
//Object Oriented Approach
//define Model 
var Customer = function(Customer){

    //Constructor

    this.custid=Customer.custid;
    this.cname = Customer.cname;
    this.cemail  = Customer.cemail ;
    this.cMobileNo  = Customer.cMobileNo ;
    this.caddress  = Customer.caddress ;
   };

//Attach member function to Model to perform DatABASE  CRUD operations

Customer.createCustomer = function (newCustomer, result) {  
        console.log("New Customer to be added ...!!!");
        console.log(newCustomer);
        sql.query("INSERT INTO customers set ?", newCustomer, function (err, res) {
                if(err) {
                  console.log("error: ", err);
                  result(err, null);
                }
                else{
                  console.log(res.insertId);
                  result(null, res.insertId);
                }
            });           
};

Customer.getCustomerById = function (CustomerId, result) {
        sql.query("Select * from customers where custid = ?", CustomerId, function (err, res) {             
                if(err) {
                  console.log("error: ", err);
                  result(err, null);
                }
                else{
                  result(null, res);     
                }
            });   
};


Customer.getAllCustomer = function (result) {
      console.log("Invoking dal getall Customers");
      
        sql.query("Select * from customers", function (err, res) {
                if(err) {
                  console.log("error: ", err);
                  result(null, err);
                }
                else{
                  console.log('customers : ', res);  
                  result(null, res);
                }
            });   
};
//???
Customer.updateById = function(custid, Customer, result){

  sql.query("UPDATE customers SET cname = ? WHERE custid = ?", [Customer.cname, custid], 
              function (err, res) {
                  if(err) {
                        console.log("error: ", err);
                        result(null, err);
                    }
                  else{   
                    result(null, res);
                    }
                }); 
};


Customer.remove = function(custid, result){
    sql.query("DELETE FROM customers WHERE custid = ?", [custid],
                function (err, res) {
                  if(err) {
                      console.log("error: ", err);
                      result(null, err);
                  }
                  else{
                      result(null, res);
                  }
            }); 
};

module.exports=Customer;