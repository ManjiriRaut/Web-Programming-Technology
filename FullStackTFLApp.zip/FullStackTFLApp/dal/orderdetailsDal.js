//************************************ */
//a Separate responsibility  for  Flowers database crud operation
var sql = require('./mysqlconnect');

//model
//Object Oriented Approach
//define Model 
var Orderdetails = function(Orderdetails){

    //Constructor
    this.orderdetailid=Orderdetails.orderdetailid
    this.orderid = Orderdetails.orderid;
    this.flowerid = Orderdetails.flowerid;
    this.quantity = Orderdetails.quantity;
};

//Attach member function to Model to perform DatABASE  CRUD operations

Orderdetails.createOrderdetails = function (newOrderdetails, result) {  
        console.log("New Orderdetails to be added ...!!!");
        console.log(newOrderdetails);
        sql.query("INSERT INTO orderdetails set ?", newOrderdetails, function (err, res) {
                if(err) {
                  console.log("error: ", err);
                  result(err, null);
                }
                else{
                  console.log(res.insertid);
                  result(null, res.insertid);
                }
            });           
};

Orderdetails.getOrderdetailsById = function (OrderId, result) {
        sql.query("Select * from orderdetails where orderdetailid = ? ", OrderId, function (err, res) {             
                if(err) {
                  console.log("error: ", err);
                  result(err, null);
                }
                else{
                  result(null, res);     
                }
            });   
};


Orderdetails.getAllOrderdetails = function (result) {
      console.log("Invoking dal getall Orderdetails");
      
        sql.query("Select * from orderdetails", function (err, res) {
                if(err) {
                  console.log("error: ", err);
                  result(null, err);
                }
                else{
                  console.log('Orderdetails : ', res);  
                  result(null, res);
                }
            });   
};

Orderdetails.updateById = function(id, Order, result){

  sql.query("UPDATE orderdetails SET flowerid = ? WHERE orderdetailid = ?", [Order.flowerid, id], 
              function (err, res) {
                  if(err) {
                        console.log("error: ", err);
                        result(null, err);
                    }
                  else{   
                    result(null, res);
                    }
                }); 
};


Orderdetails.remove = function(id, result){
    sql.query("DELETE FROM orderdetails WHERE orderdetailid = ?", [id],
                function (err, res) {
                  if(err) {
                      console.log("error: ", err);
                      result(null, err);
                  }
                  else{
                      result(null, res);
                  }
            }); 
};

module.exports=Orderdetails;