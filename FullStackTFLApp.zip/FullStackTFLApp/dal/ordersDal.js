//************************************ */
//a Separate responsibility  for  Flowers database crud operation
var sql = require('./mysqlconnect');

//model
//Object Oriented Approach
//define Model 
var Order = function(Order){

    //Constructor
    this.orderid=Order.orderid
    this.orderdate = Order.orderdate;
    this.custid = Order.custid;
    this.amount = Order.amount;
};

//Attach member function to Model to perform DatABASE  CRUD operations

Order.createOrder = function (newOrder, result) {  
        console.log("New Order to be added ...!!!");
        console.log(newOrder);
        sql.query("INSERT INTO orders set ?", newOrder, function (err, res) {
                if(err) {
                  console.log("error: ", err);
                  result(err, null);
                }
                else{
                  console.log(res.insertId);
                  result(null, res.insertId);
                }
            });           
};

Order.getOrderById = function (OrderId, result) {
        sql.query("Select * from orders where orderid = ? ", OrderId, function (err, res) {             
                if(err) {
                  console.log("error: ", err);
                  result(err, null);
                }
                else{
                  result(null, res);     
                }
            });   
};


Order.getAllOrder = function (result) {
      console.log("Invoking dal getall Orders");
      
        sql.query("Select * from orders", function (err, res) {
                if(err) {
                  console.log("error: ", err);
                  result(null, err);
                }
                else{
                  console.log('Order : ', res);  
                  result(null, res);
                }
            });   
};

Order.updateById = function(id, Order, result){

  sql.query("UPDATE orders SET custid = ? WHERE orderid = ?", [Order.custid, id], 
              function (err, res) {
                  if(err) {
                        console.log("error: ", err);
                        result(null, err);
                    }
                  else{   
                    result(null, res);
                    }
                }); 
};


Order.remove = function(id, result){
    sql.query("DELETE FROM orders WHERE orderid = ?", [id],
                function (err, res) {
                  if(err) {
                      console.log("error: ", err);
                      result(null, err);
                  }
                  else{
                      result(null, res);
                  }
            }); 
};

module.exports=Order;